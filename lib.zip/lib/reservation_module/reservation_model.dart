import 'dart:convert';
import 'package:app1/customer_module/customer_model.dart';
import 'package:app1/table_module/table_model.dart';

// Parse list of reservations
List<ModelReservation> modelReservationFromJson(String str) {
  try {
    final dynamic decodedJson = json.decode(str);
    print("Debug: Decoded JSON: $decodedJson");

    if (decodedJson == null || decodedJson is! Map<String, dynamic>) {
      print(
          "Debug: Decoded JSON is null or not a Map<String, dynamic>. Type: ${decodedJson.runtimeType}");
      return [];
    }

    final Map<String, dynamic> jsonResponse = decodedJson;
    final dynamic dataField = jsonResponse["data"];

    // Check if data field exists and is a list
    if (dataField == null) {
      print("Debug: 'data' field is null in JSON response.");
      return [];
    }

    if (dataField is! List) {
      print(
          "Debug: 'data' field is not a List in JSON response. Type: ${dataField.runtimeType}");
      return [];
    }

    // Explicitly cast dataField to List<dynamic> after null and type checks
    final List<dynamic> data = dataField as List<dynamic>;

    // Filter out any null items before mapping to ModelReservation
    final List<ModelReservation> reservations = data
        .where((item) => item != null && item is Map<String, dynamic>)
        .map((item) => ModelReservation.fromJson(item as Map<String, dynamic>))
        .toList();

    print("Debug: Successfully parsed ${reservations.length} reservations.");
    return reservations;
  } catch (e) {
    print("Error in modelReservationFromJson: $e");
    return [];
  }
}

// Convert back to JSON string
String modelReservationToJson(List<ModelReservation> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

// Reservation Model
class ModelReservation {
  final int id;
  final int customerId;
  final int tableId;
  final String dateTime;
  final String note;
  final String? createdAt;
  final String? updatedAt;
  final ModelCustomer? customer;
  final ModelTable? table;

  ModelReservation({
    required this.id,
    required this.customerId,
    required this.tableId,
    required this.dateTime,
    required this.note,
    this.createdAt,
    this.updatedAt,
    this.customer,
    this.table,
  });

  factory ModelReservation.fromJson(Map<String, dynamic> json) =>
      ModelReservation(
        id: json["id"] ?? 0,
        customerId: json["customer_id"] ?? 0,
        tableId: json["table_id"] ?? 0,
        dateTime: json["date_time"] ?? '',
        note: json["note"] ?? '',
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
        customer: json["customer"] != null
            ? ModelCustomer.fromJson(json["customer"])
            : null,
        table:
            json["table"] != null ? ModelTable.fromJson(json["table"]) : null,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "customer_id": customerId,
        "table_id": tableId,
        "date_time": dateTime,
        "note": note,
        "created_at": createdAt,
        "updated_at": updatedAt,
        if (customer != null) "customer": customer!.toJson(),
        if (table != null) "table": table!.toJson(),
      };
}
